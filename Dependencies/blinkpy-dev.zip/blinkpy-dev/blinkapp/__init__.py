"""Python init file for blinkapp.py."""
