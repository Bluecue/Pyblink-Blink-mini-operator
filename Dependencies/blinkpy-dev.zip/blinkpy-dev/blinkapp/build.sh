#!/bin/bash
docker build -t fronzbot/blinkpy:latest ./
